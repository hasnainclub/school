#!/bin/bash
# what do you see the first time you [run] the script?
# Answer
# I am ./selfModNow.sh and I am going to modify myself!
# Here is a little change...
# ... what would it show if you were to run it n times?
# Answer
# Here is a little change... (several times, each for run)
echo "I am $0 and I am going to modify myself!"
echo "echo \"Here is a little change...\"" >> $0
