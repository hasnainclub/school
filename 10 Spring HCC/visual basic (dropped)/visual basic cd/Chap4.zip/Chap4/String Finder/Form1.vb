Public Class Form1

    Private Sub btnGo_Click(ByVal sender As System.Object, _
        ByVal e As System.EventArgs) Handles btnGo.Click


    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, _
        ByVal e As System.EventArgs) Handles btnClose.Click

        Me.Close()
    End Sub

End Class
