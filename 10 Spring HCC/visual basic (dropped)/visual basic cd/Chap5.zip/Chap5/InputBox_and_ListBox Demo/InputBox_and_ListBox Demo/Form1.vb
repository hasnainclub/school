﻿Public Class Form1

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim strUserInput As String
        strUserInput = InputBox("Enter the distance.", "Provide a value", "150")

    End Sub


End Class
