Public Class frmError

End Class